# ESP32-and-how-to-use-ILI9341-TFT-Display

These examples show how to connect/wire an ILI9341 TFT display. If you have a different type of ESP32, then use different pins as required and replciate them in the code prefix.
