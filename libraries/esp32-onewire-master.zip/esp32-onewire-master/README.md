### esp32-ds18x20

This ESP32 component is a subcomponent from the excellent [ESP-IDF Components library](https://github.com/UncleRus/esp-idf-lib). This is not my original code; it is here only as a matter of convenience for inclusion in other projects that utilize the OWB.