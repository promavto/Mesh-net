### Guidelines

Pull requests are appreciated and will be considered for merge on a case-by-case basis.

Before submitting a pull request, please verify that the code builds against the specified esp-idf version, and that you've performed a clean build.
